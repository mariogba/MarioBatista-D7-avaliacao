﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MarioBatistaD7avaliacao

{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void Submit_Click(object sender, RoutedEventArgs e)
        {
            var Username = UserNameText.Text;
            var Password = PasswordText.Password;
          
            

            using (UserDataContext context = new UserDataContext())
            {
                bool userfound = context.Users.Any(User => User.Name == Username && User.Password == Password);

                if (userfound)
                {
                    MessageBox.Show("Usuário autenticado!");

                    Close();

                   

                }

                else
                {
                    MessageBox.Show("Credenciais inválidas!");
                    Close();
                }
            }

        }



      




    }
}
